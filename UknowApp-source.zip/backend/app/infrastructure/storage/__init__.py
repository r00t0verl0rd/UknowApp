"""Persistent file storage adapters."""
