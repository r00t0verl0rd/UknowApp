"""Participant conversations domain."""
