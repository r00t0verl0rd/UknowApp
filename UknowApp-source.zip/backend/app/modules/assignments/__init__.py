"""Teacher/student assignment domain."""
