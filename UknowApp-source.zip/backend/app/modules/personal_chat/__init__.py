"""Private administrator conversations domain."""
